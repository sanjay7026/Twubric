import React from 'react'

const Chirpiness = () => {
    return (
        <div>
            <h2>Chirpiness Page</h2>
        </div>
    )
}

export default Chirpiness;
