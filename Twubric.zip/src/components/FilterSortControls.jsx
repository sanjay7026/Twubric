import React from 'react';
import DatePicker from './DatePicker';

const FilterSortControls = ({ onSort, onFilter, sortCriteria }) => {
    const handleSortClick = () => {
        if (typeof onSort === 'function') {
            onSort('twubricScore');
        } else {
            console.error('onSort is not a function');
        }
    };
    return (
        <div className="controls m-2">
            <div className="sort-controls">
                <button onClick={handleSortClick} className='btn btn-success'>
                    Sort by Twubric Score {sortCriteria === 'twubricScore' ? '↑' : '↓'}
                </button>
                {/* Add more sorting buttons as needed */}
            </div>
            <div className="filter-controls">
                <DatePicker onDateSelect={onFilter} />
            </div>
        </div>
    );
};
export default FilterSortControls;
