import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const CustomDatePicker = ({ onDateSelect }) => {
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);

    const handleChangeStart = (date) => {
        setStartDate(date);
        if (endDate && typeof onDateSelect === 'function') {
            onDateSelect(date, endDate);
        }
    };

    const handleChangeEnd = (date) => {
        setEndDate(date);
        if (startDate && typeof onDateSelect === 'function') {
            onDateSelect(startDate, date);
        }
    };

    return (
        <div className="date-picker m-2">
            <DatePicker
                selected={startDate}
                selectsStart
                startDate={startDate}
                endDate={endDate}
                onChange={handleChangeStart}
                placeholderText="Start Date"
            />
            <DatePicker
                selected={endDate}
                selectsEnd
                startDate={startDate}
                endDate={endDate}
                onChange={handleChangeEnd}
                placeholderText="End Date"
            />
        </div>
    );
};

export default CustomDatePicker;
