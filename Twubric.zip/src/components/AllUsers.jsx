import React, { useEffect, useState } from 'react'
import { getAllUsers, userDelete } from '../services/userServices';
import FilterSortControls from './FilterSortControls';

const AllUsers = () => {
    const [userData, setUserData] = useState([]);

    useEffect(() => {
        getAllUsers()
            .then(res => {
                // console.log(res.data)
                setUserData(res.data)
            })
            .catch(err => console.log(err));
    }, []);

    const formatDate = (dateString) => {
        return new Intl.DateTimeFormat('en-us', {
            month: 'long',
            day: 'numeric',
            year: 'numeric'
        }).format(new Date(dateString));
    };
    const delUser = (uid) => {
        if (window.confirm('Do you want delete')) {
            userDelete(uid)
                .then(res => {
                    if (res.user) {
                        alert('User is deleted')
                        setUserData(userData.filter((user) => user.uid !== uid))
                    } else {
                        console.log("User deletion failed or user was not found in response.");
                    }
                })
                .catch(err => console.log(err))
        }
    };
    return (
        <div className='m-3'>
            <div className='d-flex justify-content-center'>
                <FilterSortControls />
            </div>
            <h2>All list of the user’s Twitter</h2>
            <div className='row d-flex justify-content-center'>
                {userData.map(user =>
                    <div key={user.uid} className='col-sm-3 m-1'>
                        <div className="card" style={{ width: '18rem' }}>
                            <div className="card-body">
                                <h5 className="card-title d-flex justify-content-between">
                                    <span>{user.fullname}</span>
                                    <span>{user.twubric.total}</span>
                                </h5>
                                <div className="card-text d-flex justify-content-between text-center">
                                    <span>Friends <br />{user.twubric.friends}</span>
                                    <span>Influence <br />{user.twubric.influence}</span>
                                    <span>Chirpiness <br />{user.twubric.chirpiness}</span>
                                </div>
                                <p>{formatDate(user.join_date)}</p>
                                <button className="btn btn-danger" onClick={() => delUser(user.uid)}>Delete</button>
                            </div>
                        </div>
                    </div>
                )}

            </div>
        </div>
    )
}

export default AllUsers;
