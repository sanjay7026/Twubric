import React from 'react'

const Friends = () => {
    return (
        <div>
            <h2>Friends Page</h2>
        </div>
    )
}

export default Friends;
