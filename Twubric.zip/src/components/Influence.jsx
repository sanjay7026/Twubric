import React from 'react'

const Influence = () => {
    return (
        <div>
            <h2>Influence Page</h2>
        </div>
    )
}

export default Influence;
