import axios from "axios";

const API_URL = 'https://gist.githubusercontent.com/pandemonia/21703a6a303e0487a73b2610c8db41ab/raw/82e3ef99cde5b6e313922a5ccce7f38e17f790ac/twubric.json';

const getAllUsers = () =>{
    return axios.get(API_URL)
};
const userDelete = (uid) =>{
    return axios.delete(`${API_URL}/${uid}`)
};

export {getAllUsers, userDelete }