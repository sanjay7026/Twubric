import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Nav from './components/Nav';
import Friends from './components/Friends';
import Influence from './components/Influence';
import Chirpiness from './components/Chirpiness';
import AllUsers from './components/AllUsers';
import FilterSortControls from './components/FilterSortControls';
function App() {
  return (
    <div className="container">
      <Router>
      {/* <FilterSortControls /> */}
        <Nav />
        <Routes>
          <Route path='/' element={<Friends />} />
          <Route path='influence' element={<Influence />} />
          <Route path='chirpiness' element={<Chirpiness />} />
          <Route path='allUser' element={<AllUsers />} />
        </Routes>
      </Router>
      
    </div>
  );
}

export default App;
